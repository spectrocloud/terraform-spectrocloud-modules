# Spectro Cloud credentials
sc_host         = "api.spock.spectrocloud.com" #e.g: api.spectrocloud.com (for SaaS)
#sc_api_key      = "MzIxYTc2ZmExZjQzMWJhZjExMmMyMjM2N2UyOGQzMzk="      #e.g: Q28GBs7ssdvNNkERWeWpqwSLfI1nnit6W
sc_api_key      = "MjBmYzE4YjE5YzJlMTc1MTMxYzA5YTljMTg1ODYyOTc=" # API for GE tenant in spock env
sc_project_name = "hospital-2" #e.g: Default




#sc_host         = "api.spock.spectrocloud.com" #e.g: api.spectrocloud.com (for SaaS)
##sc_api_key      = "MzIxYTc2ZmExZjQzMWJhZjExMmMyMjM2N2UyOGQzMzk="      #e.g: Q28GBs7ssdvNNkERWeWpqwSLfI1nnit6W
#sc_api_key      = "MjBmYzE4YjE5YzJlMTc1MTMxYzA5YTljMTg1ODYyOTc=" # API for GE tenant in spock env
#sc_project_name = "edge-native" #e.g: Default


